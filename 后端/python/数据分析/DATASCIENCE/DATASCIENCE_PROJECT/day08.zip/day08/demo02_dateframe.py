"""
demo02_dateframe.py   数据框操作
"""
import numpy as np
import pandas as pd

# 创建空df
df = pd.DataFrame()
print(df)

# 通过列表数据源创建df
print('-' * 45)
data = [80, 90, 70, 77]
df = pd.DataFrame(data)
print(df)

# 通过二维数据集构建df
data = [['Tom', 80], ['Jerry', 70], ['Alex', 25]]
df = pd.DataFrame(data, 
	index=['101','102','103'], 
	columns=['name', 'score'])
print('-' * 45)
print(df)

# 
print('-' * 45)
df = pd.DataFrame(
	[{'name':'zs', 'age':10}, 
	 {'name':'ls', 'age':12, 'score':90}])
print(df)

# 通过字典构建df
data = {'Name':['Tom', 'Jack', 'Steve', 'Ricky'],'Age':[28,34,29,42]}
df = pd.DataFrame(data, index=['01','02','03','04'])
print('-' * 45)
print(df)

# 列访问
print('-' * 45)
print(df['Name'])
print(df[['Name', 'Age']])

# 列添加
print('-' * 45)
df['score'] = pd.Series(
	[90, 80, 77, 36], index=df.index)
print(df)

# 列删除
print('-' * 45)
df.pop('score')
print(df)

# 行访问
print('-' * 45)
print(df[-3:])

print('-' * 45)
print(df.loc[['02','04']])  # 通过索引标签访问行

print('-' * 45)
print(df.iloc[[0, 2]])  # 通过索引下标访问行

# 行添加
data = {'Name':['Lily', 'Lucy'],
        'Age':[28, 34]}
df2 = pd.DataFrame(data, index=['05','06'])
df = df.append(df2)
print('-' * 45)
print(df)

# 行删除
df = df.drop(['05', '03'])
print('-' * 45)
print(df)

# 修改元素
df['Age'] = 40
print(df)
df['Age']['04'] = 23
print(df)

print(df.values)
print(df.head(2))
print(df.tail(2))
