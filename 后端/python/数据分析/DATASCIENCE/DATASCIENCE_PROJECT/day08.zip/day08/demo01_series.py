"""
demo01_series.py   Series基础
"""
import numpy as np
import pandas as pd

# 空Series
s = pd.Series()
print(s)

# 通过data构建Series
data = np.array(['zs', 'ls', 'ww', 'zl'])
s = pd.Series(data)
print(s)

# 指定index名称(以学号作为index) 构建Series
data = np.array(['zs', 'ls', 'ww', 'zl'])
s = pd.Series(
	data, index=['1001','1002','1003','1004'])
print(s)

# 通过字典创建Series
s = pd.Series({'zs':80, 'ls':90, 'ww':70})
print('---\n', s)

# 通过标量创建Series
s = pd.Series(5, index=['a', 'b', 'c', 'd'])
print('---\n', s)

# 构建Series  访问元素
data = np.array(['zs', 'ls', 'ww', 'zl'])
s = pd.Series(
	data, index=['1001','1002','1003','1004'])
print('---\n', s)
print('s[2]: ', s[2])	# 通过索引下标访问元素
print('s[2:]: \n', s[2:]) # 通过索引切片访问
print('s["1003"]:', s['1003']) # 通过索引标签访问元素
print(s[['1001', '1002', '1004']])


# 测试pandas的日期相关处理
print('-' * 45)
dates = pd.Series(
	['2011', '2011-02', '2011-03-01', '2011/04/01', 
     '2011/05/01 01:01:01', '01 Jun 2011'])
dates = pd.to_datetime(dates)
print(dates)
print('dates months:')
print(dates.dt.month)

# 日期运算
print('-' * 45)
delta = dates - pd.to_datetime('1970')
print(delta)
print(delta.dt.days)

# 生成时间序列
print('-' * 45)
dates = pd.date_range(
	'2019-10-01', periods=7, freq='M')
print(dates)

dates = pd.bdate_range(
	'2019-11-01', periods=7)
print(dates)

